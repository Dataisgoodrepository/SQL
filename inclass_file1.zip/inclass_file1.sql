-- to create a database


-- double click on database to use it
-- to use/open a database



-- to a create table


-- to see the structure table



-- ALTER stuructre
-- to add a new attribute



-- to remove/delete attribute



-- to change the existing datatype


-- replace the column name and datatype both


-- rename the column




-- HR Schema
-- DDL - Create database, table
 -- Alter add , drop, modify, rename, change 
 -- Drop, Truncate
 -- rename table
 alter table student rename to students;
 -- delete/drop a table
 drop table students;
 drop database day1;
 
 Truncate -- delete all data and retain the data structure 
 truncate from students;
 desc students;
 
 
 -- DML update, insert, delete
 insert into students values
 (101, 'XXX', 'DSE', 25, 80);
 
 insert into students
 (course, age, mark, rollno,name)
 values
 ('BABI', 27, 75, 102, 'YYY');
 
  insert into students 
  (rollno, name, course, age)
  values
 (103, 'ZZZ', 'DSE', 27);
 
 insert into students
 values
 (104, 'AAA', 'DBMS', 28, NULL); 
 
select * from students;
select rollno, name from students;

desc students;
-- list all tables under the database
show tables;

insert into students values
(105, 'vidya', 'DSE', 35, 78),
(106, 'Ravi', 'BABI', 29, 67);

-- update score of student 101 to 85

update students set mark=85
where rollno=101;

update students set mark=90
where course='DSE';

update students set mark=90
where mark is NULL;


-- Delete
delete from students;

delete from students
where rollno=106;

-- date datetime time

create table date_type
(
dt date,
dtime datetime,
ti time
);

desc date_type;

select current_date() from dual;
select current_time() from dual;
select now() from dual;


insert into date_type
values
(current_date(),now(), current_time());

select current_date(), current_time(), now() from dual;
select * from date_type;

insert into date_type
values
('2020-01-28','2020-02-15 08:30:00', '20:25:12');

-- 28-01-2020 / YYYY-MM-DD
 -- 08:30:00/HH:MM:SS


select * from employees
 
 -- list the employee_id and first_name those salary GT 10000


 
 -- list the employees working for department 80 -- 34 rows

 
 -- list employees other than working for department 30

  
  -- list employees who are working for department 80 and 90 -- 34 rows

  
-- list employees working for dept 80 and earning salary more than 5000
-- 34 rows

 
 -- List employees working for 80 90 100 120

 
 -- list employees who are earning salary > 5000 and <10000 

 
 -- Like operator
 -- soundex, pattern matching
 -- wild card char % multiple char, _ single char
 
 -- list first_name whose name strats with 's'
 

 
 -- list first_name whose name ends with 's'

 
 -- list first_name whose name contain 'le'

 
 -- list first_name whose name contains 'l' as second character

 











